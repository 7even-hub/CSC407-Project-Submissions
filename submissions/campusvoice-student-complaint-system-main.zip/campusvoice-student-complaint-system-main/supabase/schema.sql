-- CampusVoice initial Supabase schema
-- Run this in a new Supabase project's SQL editor.

create type public.user_role as enum ('student', 'staff', 'admin');
create type public.complaint_status as enum ('submitted', 'under_review', 'assigned', 'in_progress', 'resolved', 'closed', 'reopened');
create type public.complaint_priority as enum ('low', 'normal', 'high', 'urgent');

create table public.departments (
  id uuid primary key default gen_random_uuid(),
  name text not null unique check (char_length(name) between 2 and 100),
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null check (char_length(full_name) between 2 and 120),
  student_id text unique,
  role public.user_role not null default 'student',
  department_id uuid references public.departments(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.complaints (
  id uuid primary key default gen_random_uuid(),
  reference text not null unique default ('SCMS-' || to_char(now(), 'YYYY') || '-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8))),
  student_id uuid not null references public.profiles(id) on delete restrict,
  department_id uuid references public.departments(id) on delete set null,
  assigned_to uuid references public.profiles(id) on delete set null,
  title text not null check (char_length(title) between 5 and 120),
  category text not null check (char_length(category) between 2 and 80),
  description text not null check (char_length(description) between 30 and 4000),
  requested_outcome text check (requested_outcome is null or char_length(requested_outcome) <= 1200),
  incident_date date not null check (incident_date <= current_date),
  location text check (location is null or char_length(location) <= 160),
  is_confidential boolean not null default false,
  status public.complaint_status not null default 'submitted',
  priority public.complaint_priority not null default 'normal',
  resolved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.complaint_updates (
  id uuid primary key default gen_random_uuid(),
  complaint_id uuid not null references public.complaints(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete restrict,
  message text not null check (char_length(message) between 1 and 3000),
  status public.complaint_status,
  is_internal boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.attachments (
  id uuid primary key default gen_random_uuid(),
  complaint_id uuid not null references public.complaints(id) on delete cascade,
  uploaded_by uuid not null references public.profiles(id) on delete restrict,
  storage_path text not null unique,
  original_name text not null,
  mime_type text not null check (mime_type in ('application/pdf', 'image/jpeg', 'image/png')),
  byte_size integer not null check (byte_size > 0 and byte_size <= 5242880),
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id) on delete set null,
  complaint_id uuid references public.complaints(id) on delete set null,
  action text not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index complaints_student_idx on public.complaints(student_id);
create index complaints_status_idx on public.complaints(status);
create index complaints_department_idx on public.complaints(department_id);
create index complaint_updates_complaint_idx on public.complaint_updates(complaint_id, created_at);

create or replace function public.current_user_role()
returns public.user_role
language sql
stable
security definer
set search_path = public
as $$ select role from public.profiles where id = auth.uid() $$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, student_id)
  values (
    new.id,
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''), 'New student'),
    nullif(trim(new.raw_user_meta_data ->> 'student_id'), '')
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

alter table public.departments enable row level security;
alter table public.profiles enable row level security;
alter table public.complaints enable row level security;
alter table public.complaint_updates enable row level security;
alter table public.attachments enable row level security;
alter table public.audit_logs enable row level security;

create policy "Authenticated users read departments"
on public.departments for select to authenticated
using (true);

create policy "Users read their own profile"
on public.profiles for select to authenticated
using (id = auth.uid() or public.current_user_role() in ('staff', 'admin'));

create policy "Users update safe fields on their profile"
on public.profiles for update to authenticated
using (id = auth.uid())
with check (id = auth.uid() and role = public.current_user_role());

create policy "Students read their own complaints"
on public.complaints for select to authenticated
using (
  student_id = auth.uid()
  or public.current_user_role() = 'admin'
  or (public.current_user_role() = 'staff' and department_id = (select department_id from public.profiles where id = auth.uid()))
);

create policy "Students create their own complaints"
on public.complaints for insert to authenticated
with check (student_id = auth.uid() and public.current_user_role() = 'student' and status = 'submitted');

create policy "Authorized staff update complaints"
on public.complaints for update to authenticated
using (
  public.current_user_role() = 'admin'
  or (public.current_user_role() = 'staff' and department_id = (select department_id from public.profiles where id = auth.uid()))
)
with check (
  public.current_user_role() = 'admin'
  or (public.current_user_role() = 'staff' and department_id = (select department_id from public.profiles where id = auth.uid()))
);

create policy "Authorized users read complaint updates"
on public.complaint_updates for select to authenticated
using (
  exists (
    select 1 from public.complaints c
    where c.id = complaint_id
      and (
        c.student_id = auth.uid()
        or public.current_user_role() = 'admin'
        or (public.current_user_role() = 'staff' and c.department_id = (select department_id from public.profiles where id = auth.uid()))
      )
  )
  and (not is_internal or public.current_user_role() in ('staff', 'admin'))
);

create policy "Participants create complaint updates"
on public.complaint_updates for insert to authenticated
with check (
  author_id = auth.uid()
  and exists (
    select 1 from public.complaints c
    where c.id = complaint_id
      and (
        c.student_id = auth.uid()
        or public.current_user_role() = 'admin'
        or (public.current_user_role() = 'staff' and c.department_id = (select department_id from public.profiles where id = auth.uid()))
      )
  )
  and (not is_internal or public.current_user_role() in ('staff', 'admin'))
);

create policy "Authorized users read attachment metadata"
on public.attachments for select to authenticated
using (
  exists (
    select 1 from public.complaints c
    where c.id = complaint_id
      and (
        c.student_id = auth.uid()
        or public.current_user_role() = 'admin'
        or (public.current_user_role() = 'staff' and c.department_id = (select department_id from public.profiles where id = auth.uid()))
      )
  )
);

create policy "Complaint owners upload attachment metadata"
on public.attachments for insert to authenticated
with check (
  uploaded_by = auth.uid()
  and exists (select 1 from public.complaints c where c.id = complaint_id and c.student_id = auth.uid())
);

create policy "Admins read audit logs"
on public.audit_logs for select to authenticated
using (public.current_user_role() = 'admin');

-- Role changes and audit-log inserts should be performed only by trusted server-side functions.
-- Create a private Storage bucket named complaint-evidence and mirror complaint authorization
-- in storage.objects policies before enabling production uploads.

