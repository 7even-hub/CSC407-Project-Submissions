# CampusVoice

CampusVoice is a full-stack Student Complaint Management System with a responsive public site, student and administrator workspaces, secure account access, complaint submission and tracking, profile management, security documentation, and testing evidence.

## Architecture

- **Frontend:** buildless HTML, CSS, and JavaScript SPA served by the Node service
- **Web service:** Node.js HTTP API and static application server
- **Database:** PostgreSQL in production; an in-memory adapter is used only when `DATABASE_URL` is absent during local development and automated tests
- **Authentication:** bcrypt password hashes, opaque server-side sessions, HTTP-only same-site cookies, and CSRF tokens
- **Authorization:** student/admin access checks are enforced by the API; students can only read their own complaints

## Run locally

```powershell
npm install
npm run dev
```

Open `http://127.0.0.1:4173`. Without `DATABASE_URL`, local data is intentionally reset whenever the process restarts.

For persistent local data, copy `.env.example`, create a PostgreSQL database, and provide `DATABASE_URL` in the process environment before starting the service.

## Verify

```powershell
npm test
npm run build
```

The test suite covers structural UI requirements plus registration validation, authentication, sessions, CSRF enforcement, complaint creation/retrieval, XSS-safe data flow, and role restrictions.

## Production security controls

- Passwords hashed with bcrypt at cost 12
- Random opaque session tokens stored as SHA-256 hashes
- Secure, HTTP-only, SameSite=Strict cookies
- CSRF token checks on authenticated mutations
- Origin validation and request rate limiting
- Parameterized PostgreSQL queries
- Server-side input validation and body-size limits
- Role and ownership checks on every complaint query
- Content Security Policy and defensive response headers
- Audit records for complaint creation and administrative status changes

## Render deployment

`render.yaml` preserves the existing static preview and adds:

- `campusvoice-web`: the real Node Web Service
- `campusvoice-db`: the managed PostgreSQL database

The web service builds the frontend, runs the database migrations at startup, serves the application, and exposes `/api/health` for Render health checks.

To provision an administrator, add `ADMIN_NAME`, `ADMIN_EMAIL`, and a strong `ADMIN_PASSWORD` (minimum 12 characters) to the Web Service environment. The administrator is created only when the email does not already exist.

## Supabase option

The original Supabase Auth/RLS design remains in `supabase/schema.sql` as an alternative hosted-data architecture. The deployed Render Web Service uses managed PostgreSQL directly so the application has an explicit backend service and can enforce all authorization server-side.
