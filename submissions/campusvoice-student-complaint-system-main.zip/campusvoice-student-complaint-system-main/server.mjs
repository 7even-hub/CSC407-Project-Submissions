import { createServer } from 'node:http';
import { access, readFile, stat } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { createHash, randomBytes, randomUUID } from 'node:crypto';
import bcrypt from 'bcryptjs';
import pg from 'pg';

const { Pool } = pg;
const port = Number(process.env.PORT || 4173);
const production = process.env.NODE_ENV === 'production';
const root = process.cwd();
const dist = join(root, 'dist');
const staticRoot = await access(join(dist, 'index.html')).then(() => dist).catch(() => root);
const pool = process.env.DATABASE_URL
  ? new Pool({ connectionString: process.env.DATABASE_URL, ssl: production ? { rejectUnauthorized: false } : undefined })
  : null;
const sessions = new Map();
const users = new Map();
const complaints = new Map();
const rateLimits = new Map();

const mime = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml'
};

const categories = new Set(['Academic', 'Fees & Payments', 'Examinations', 'Facilities', 'Harassment or Misconduct', 'Student Services', 'Security', 'Other']);
const statuses = new Set(['Submitted', 'Under Review', 'Assigned', 'In Progress', 'Resolved', 'Closed', 'Reopened']);
const departmentFor = category => ({
  Academic: 'Academic Affairs',
  'Fees & Payments': 'Bursary',
  Examinations: 'Examinations & Records',
  Facilities: 'Works & Maintenance',
  'Harassment or Misconduct': 'Student Affairs',
  'Student Services': 'Student Affairs',
  Security: 'Campus Security',
  Other: 'Student Affairs'
}[category] || 'Student Affairs');

const hashToken = token => createHash('sha256').update(token).digest('hex');
const clean = value => String(value ?? '').trim();
const emailOf = value => clean(value).toLowerCase();
const publicUser = user => user ? ({
  id: user.id,
  name: user.full_name,
  email: user.email,
  role: user.role,
  studentId: user.student_id || '',
  department: user.department || ''
}) : null;

function securityHeaders(contentType = '') {
  return {
    'Content-Type': contentType,
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
    'Cross-Origin-Opener-Policy': 'same-origin',
    'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
  };
}

function sendJson(response, status, body, extra = {}) {
  response.writeHead(status, { ...securityHeaders('application/json; charset=utf-8'), 'Cache-Control': 'no-store', ...extra });
  response.end(JSON.stringify(body));
}

function parseCookies(request) {
  return Object.fromEntries((request.headers.cookie || '').split(';').filter(Boolean).map(part => {
    const index = part.indexOf('=');
    return [part.slice(0, index).trim(), decodeURIComponent(part.slice(index + 1))];
  }));
}

function sessionCookie(token, maxAge = 60 * 60 * 24 * 7) {
  return `cv_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${production ? '; Secure' : ''}`;
}

async function readJson(request) {
  let body = '';
  for await (const chunk of request) {
    body += chunk;
    if (Buffer.byteLength(body) > 64 * 1024) throw Object.assign(new Error('Request body is too large.'), { status: 413 });
  }
  try { return body ? JSON.parse(body) : {}; }
  catch { throw Object.assign(new Error('Invalid JSON body.'), { status: 400 }); }
}

function requestOriginIsValid(request) {
  const origin = request.headers.origin;
  if (!origin) return true;
  try { return new URL(origin).host === request.headers.host; }
  catch { return false; }
}

function allowed(request, bucket, limit, windowMs) {
  const ip = clean(request.headers['x-forwarded-for']).split(',')[0] || request.socket.remoteAddress || 'unknown';
  const key = `${bucket}:${ip}`;
  const now = Date.now();
  const entry = rateLimits.get(key);
  if (!entry || entry.resetAt <= now) {
    rateLimits.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  entry.count += 1;
  return entry.count <= limit;
}

async function migrate() {
  if (!pool) return;
  await pool.query(`
    create table if not exists users (
      id uuid primary key,
      full_name varchar(120) not null,
      email varchar(254) not null unique,
      password_hash text not null,
      role varchar(16) not null default 'student' check (role in ('student','staff','admin')),
      student_id varchar(80) unique,
      department varchar(120),
      created_at timestamptz not null default now(),
      updated_at timestamptz not null default now()
    );
    create table if not exists complaints (
      id uuid primary key,
      reference varchar(40) not null unique,
      student_id uuid not null references users(id) on delete restrict,
      title varchar(120) not null,
      category varchar(80) not null,
      department varchar(120) not null,
      priority varchar(16) not null default 'Normal',
      status varchar(24) not null default 'Submitted',
      incident_date date not null,
      location varchar(160),
      confidential boolean not null default false,
      description varchar(4000) not null,
      requested_outcome varchar(1200),
      created_at timestamptz not null default now(),
      updated_at timestamptz not null default now()
    );
    create index if not exists complaints_student_idx on complaints(student_id);
    create index if not exists complaints_status_idx on complaints(status);
    create table if not exists sessions (
      token_hash char(64) primary key,
      user_id uuid not null references users(id) on delete cascade,
      csrf_token varchar(80) not null,
      expires_at timestamptz not null,
      created_at timestamptz not null default now()
    );
    create index if not exists sessions_expiry_idx on sessions(expires_at);
    create table if not exists audit_logs (
      id bigserial primary key,
      actor_id uuid references users(id) on delete set null,
      complaint_id uuid references complaints(id) on delete set null,
      action varchar(80) not null,
      metadata jsonb not null default '{}'::jsonb,
      created_at timestamptz not null default now()
    );
  `);
  await pool.query('delete from sessions where expires_at < now()');
  await seedAdmin();
}

async function seedAdmin() {
  const email = emailOf(process.env.ADMIN_EMAIL);
  const password = clean(process.env.ADMIN_PASSWORD);
  if (!pool || !email || password.length < 12) return;
  const existing = await pool.query('select id from users where email = $1', [email]);
  if (existing.rowCount) return;
  const passwordHash = await bcrypt.hash(password, 12);
  await pool.query(
    `insert into users (id, full_name, email, password_hash, role, department)
     values ($1, $2, $3, $4, 'admin', 'Student Affairs')`,
    [randomUUID(), clean(process.env.ADMIN_NAME) || 'CampusVoice Administrator', email, passwordHash]
  );
}

async function findUserByEmail(email) {
  if (pool) return (await pool.query('select * from users where email = $1', [email])).rows[0] || null;
  return [...users.values()].find(user => user.email === email) || null;
}

async function findUserById(id) {
  if (pool) return (await pool.query('select * from users where id = $1', [id])).rows[0] || null;
  return users.get(id) || null;
}

async function createUser(data) {
  const user = { id: randomUUID(), full_name: data.name, email: data.email, password_hash: data.passwordHash, role: 'student', student_id: data.studentId, department: data.department, created_at: new Date() };
  if (pool) {
    const result = await pool.query(
      `insert into users (id, full_name, email, password_hash, role, student_id, department)
       values ($1,$2,$3,$4,'student',$5,$6) returning *`,
      [user.id, user.full_name, user.email, user.password_hash, user.student_id, user.department]
    );
    return result.rows[0];
  }
  users.set(user.id, user);
  return user;
}

async function createSession(userId) {
  const token = randomBytes(32).toString('base64url');
  const tokenHash = hashToken(token);
  const csrfToken = randomBytes(24).toString('base64url');
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
  if (pool) await pool.query('insert into sessions (token_hash, user_id, csrf_token, expires_at) values ($1,$2,$3,$4)', [tokenHash, userId, csrfToken, expiresAt]);
  else sessions.set(tokenHash, { user_id: userId, csrf_token: csrfToken, expires_at: expiresAt });
  return { token, csrfToken };
}

async function getSession(request) {
  const token = parseCookies(request).cv_session;
  if (!token) return null;
  const tokenHash = hashToken(token);
  let session;
  if (pool) session = (await pool.query('select * from sessions where token_hash = $1 and expires_at > now()', [tokenHash])).rows[0];
  else session = sessions.get(tokenHash);
  if (!session || new Date(session.expires_at) <= new Date()) return null;
  const user = await findUserById(session.user_id);
  return user ? { tokenHash, session, user } : null;
}

async function requireSession(request, response, csrf = false) {
  const auth = await getSession(request);
  if (!auth) {
    sendJson(response, 401, { error: 'Authentication required.' });
    return null;
  }
  if (csrf && request.headers['x-csrf-token'] !== auth.session.csrf_token) {
    sendJson(response, 403, { error: 'The security token is missing or invalid.' });
    return null;
  }
  return auth;
}

function mapComplaint(row) {
  const updated = new Date(row.updated_at || Date.now());
  return {
    id: row.reference,
    title: row.title,
    category: row.category,
    department: row.department,
    priority: row.priority,
    status: row.status,
    date: String(row.incident_date).slice(0, 10),
    updated: updated.toLocaleDateString('en-NG', { dateStyle: 'medium' }),
    description: row.description,
    outcome: row.requested_outcome || '',
    location: row.location || '',
    confidential: Boolean(row.confidential)
  };
}

async function listComplaints(user) {
  if (pool) {
    const result = user.role === 'admin'
      ? await pool.query('select * from complaints order by created_at desc')
      : await pool.query('select * from complaints where student_id = $1 order by created_at desc', [user.id]);
    return result.rows.map(mapComplaint);
  }
  return [...complaints.values()].filter(item => user.role === 'admin' || item.student_id === user.id).sort((a, b) => b.created_at - a.created_at).map(mapComplaint);
}

async function createComplaint(user, data) {
  const now = new Date();
  const reference = `SCMS-${now.getFullYear()}-${randomBytes(4).toString('hex').toUpperCase()}`;
  const record = {
    id: randomUUID(), reference, student_id: user.id, title: data.title, category: data.category,
    department: departmentFor(data.category), priority: 'Normal', status: 'Submitted',
    incident_date: data.date, location: data.location || null, confidential: data.confidential,
    description: data.description, requested_outcome: data.outcome || null, created_at: now, updated_at: now
  };
  if (pool) {
    const result = await pool.query(
      `insert into complaints (id, reference, student_id, title, category, department, priority, status, incident_date, location, confidential, description, requested_outcome)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) returning *`,
      [record.id, record.reference, record.student_id, record.title, record.category, record.department, record.priority, record.status, record.incident_date, record.location, record.confidential, record.description, record.requested_outcome]
    );
    await pool.query('insert into audit_logs (actor_id, complaint_id, action) values ($1,$2,$3)', [user.id, record.id, 'complaint.created']);
    return mapComplaint(result.rows[0]);
  }
  complaints.set(record.id, record);
  return mapComplaint(record);
}

function validateRegistration(data) {
  const name = clean(data.name);
  const email = emailOf(data.email);
  const password = String(data.password || '');
  const studentId = clean(data.studentId);
  const department = clean(data.department);
  if (name.length < 2 || name.length > 120) return 'Enter a valid full name.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return 'Enter a valid email address.';
  if (password.length < 8 || password.length > 128 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) return 'Use at least 8 characters with a letter and number.';
  if (studentId.length < 3 || studentId.length > 80) return 'Enter a valid student ID.';
  if (department.length < 2 || department.length > 120) return 'Choose a valid department.';
  return null;
}

function validateComplaint(data) {
  const title = clean(data.title);
  const description = clean(data.description);
  const outcome = clean(data.outcome);
  const location = clean(data.location);
  const date = clean(data.date);
  if (title.length < 5 || title.length > 120) return 'The title must contain 5 to 120 characters.';
  if (!categories.has(data.category)) return 'Choose a valid complaint category.';
  if (description.length < 30 || description.length > 4000) return 'The description must contain 30 to 4000 characters.';
  if (outcome.length > 1200 || location.length > 160) return 'One or more fields are too long.';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || new Date(`${date}T00:00:00Z`) > new Date()) return 'Choose a valid incident date.';
  return null;
}

async function handleApi(request, response, url) {
  const method = request.method || 'GET';
  if (!requestOriginIsValid(request)) return sendJson(response, 403, { error: 'Cross-origin request rejected.' });

  if (method === 'GET' && url.pathname === '/api/health') {
    if (pool) await pool.query('select 1');
    return sendJson(response, 200, { status: 'ok', database: pool ? 'postgresql' : 'memory', service: 'campusvoice-web' });
  }

  if (method === 'POST' && url.pathname === '/api/auth/register') {
    if (!allowed(request, 'register', 8, 15 * 60 * 1000)) return sendJson(response, 429, { error: 'Too many attempts. Try again later.' });
    const data = await readJson(request);
    const validationError = validateRegistration(data);
    if (validationError) return sendJson(response, 400, { error: validationError });
    const email = emailOf(data.email);
    if (await findUserByEmail(email)) return sendJson(response, 409, { error: 'An account already exists for this email.' });
    const passwordHash = await bcrypt.hash(String(data.password), 12);
    let user;
    try {
      user = await createUser({ name: clean(data.name), email, passwordHash, studentId: clean(data.studentId), department: clean(data.department) });
    } catch (error) {
      if (error.code === '23505') return sendJson(response, 409, { error: 'The email or student ID is already registered.' });
      throw error;
    }
    const session = await createSession(user.id);
    return sendJson(response, 201, { user: publicUser(user), csrfToken: session.csrfToken }, { 'Set-Cookie': sessionCookie(session.token) });
  }

  if (method === 'POST' && url.pathname === '/api/auth/login') {
    if (!allowed(request, 'login', 12, 15 * 60 * 1000)) return sendJson(response, 429, { error: 'Too many attempts. Try again later.' });
    const data = await readJson(request);
    const user = await findUserByEmail(emailOf(data.email));
    const valid = user && await bcrypt.compare(String(data.password || ''), user.password_hash);
    if (!valid) return sendJson(response, 401, { error: 'Email or password is incorrect.' });
    const session = await createSession(user.id);
    return sendJson(response, 200, { user: publicUser(user), csrfToken: session.csrfToken }, { 'Set-Cookie': sessionCookie(session.token) });
  }

  if (method === 'GET' && url.pathname === '/api/auth/session') {
    const auth = await getSession(request);
    return sendJson(response, 200, auth ? { user: publicUser(auth.user), csrfToken: auth.session.csrf_token } : { user: null, csrfToken: null });
  }

  if (method === 'POST' && url.pathname === '/api/auth/logout') {
    const auth = await requireSession(request, response, true);
    if (!auth) return;
    if (pool) await pool.query('delete from sessions where token_hash = $1', [auth.tokenHash]);
    else sessions.delete(auth.tokenHash);
    return sendJson(response, 200, { ok: true }, { 'Set-Cookie': sessionCookie('', 0) });
  }

  if (method === 'GET' && url.pathname === '/api/complaints') {
    const auth = await requireSession(request, response);
    if (!auth) return;
    return sendJson(response, 200, { complaints: await listComplaints(auth.user) });
  }

  if (method === 'POST' && url.pathname === '/api/complaints') {
    const auth = await requireSession(request, response, true);
    if (!auth) return;
    if (auth.user.role !== 'student') return sendJson(response, 403, { error: 'Only student accounts can submit complaints.' });
    if (!allowed(request, `complaint:${auth.user.id}`, 15, 60 * 60 * 1000)) return sendJson(response, 429, { error: 'Complaint submission limit reached. Try again later.' });
    const data = await readJson(request);
    const validationError = validateComplaint(data);
    if (validationError) return sendJson(response, 400, { error: validationError });
    const complaint = await createComplaint(auth.user, {
      title: clean(data.title), category: data.category, date: clean(data.date), location: clean(data.location),
      confidential: Boolean(data.confidential), description: clean(data.description), outcome: clean(data.outcome)
    });
    return sendJson(response, 201, { complaint });
  }

  if (method === 'PATCH' && /^\/api\/complaints\/[^/]+$/.test(url.pathname)) {
    const auth = await requireSession(request, response, true);
    if (!auth) return;
    if (auth.user.role !== 'admin') return sendJson(response, 403, { error: 'Administrator access is required.' });
    const reference = decodeURIComponent(url.pathname.split('/').pop());
    const data = await readJson(request);
    if (!statuses.has(data.status)) return sendJson(response, 400, { error: 'Choose a valid status.' });
    if (pool) {
      const result = await pool.query('update complaints set status = $1, updated_at = now() where reference = $2 returning *', [data.status, reference]);
      if (!result.rowCount) return sendJson(response, 404, { error: 'Complaint not found.' });
      await pool.query('insert into audit_logs (actor_id, complaint_id, action, metadata) values ($1,$2,$3,$4)', [auth.user.id, result.rows[0].id, 'complaint.status_changed', JSON.stringify({ status: data.status })]);
      return sendJson(response, 200, { complaint: mapComplaint(result.rows[0]) });
    }
    const record = [...complaints.values()].find(item => item.reference === reference);
    if (!record) return sendJson(response, 404, { error: 'Complaint not found.' });
    record.status = data.status; record.updated_at = new Date();
    return sendJson(response, 200, { complaint: mapComplaint(record) });
  }

  if (method === 'PUT' && url.pathname === '/api/profile') {
    const auth = await requireSession(request, response, true);
    if (!auth) return;
    const data = await readJson(request);
    const name = clean(data.name);
    if (name.length < 2 || name.length > 120) return sendJson(response, 400, { error: 'Enter a valid full name.' });
    let user;
    if (pool) user = (await pool.query('update users set full_name = $1, updated_at = now() where id = $2 returning *', [name, auth.user.id])).rows[0];
    else { auth.user.full_name = name; user = auth.user; }
    return sendJson(response, 200, { user: publicUser(user) });
  }

  return sendJson(response, 404, { error: 'API endpoint not found.' });
}

async function serveStatic(request, response, url) {
  if (!['GET', 'HEAD'].includes(request.method || 'GET')) return sendJson(response, 405, { error: 'Method not allowed.' });
  const rawPath = decodeURIComponent(url.pathname);
  const safePath = normalize(rawPath).replace(/^([/\\]*\.\.[/\\])+/, '').replace(/^[/\\]+/, '');
  let filePath = join(staticRoot, safePath || 'index.html');
  try {
    if ((await stat(filePath)).isDirectory()) filePath = join(filePath, 'index.html');
  } catch {
    filePath = join(staticRoot, 'index.html');
  }
  const data = await readFile(filePath);
  const type = mime[extname(filePath)] || 'application/octet-stream';
  const cache = extname(filePath) === '.html' ? 'no-cache' : 'public, max-age=3600';
  response.writeHead(200, { ...securityHeaders(type), 'Cache-Control': cache });
  if (request.method === 'HEAD') return response.end();
  response.end(data);
}

await migrate();

createServer(async (request, response) => {
  try {
    const url = new URL(request.url, `http://${request.headers.host}`);
    if (url.pathname.startsWith('/api/')) await handleApi(request, response, url);
    else await serveStatic(request, response, url);
  } catch (error) {
    console.error('request_failed', { message: error.message, path: request.url });
    if (!response.headersSent) sendJson(response, error.status || 500, { error: error.status ? error.message : 'Something went wrong. Please try again.' });
    else response.end();
  }
}).listen(port, '0.0.0.0', () => {
  console.log(`CampusVoice web service listening on port ${port} (${pool ? 'PostgreSQL' : 'in-memory development store'})`);
});

process.on('SIGTERM', async () => {
  await pool?.end();
  process.exit(0);
});
