import { readFile } from 'node:fs/promises';
import { strict as assert } from 'node:assert';

const [html, css, js, schema, render, server] = await Promise.all([
  readFile('index.html', 'utf8'),
  readFile('styles.css', 'utf8'),
  readFile('app.js', 'utf8'),
  readFile('supabase/schema.sql', 'utf8'),
  readFile('render.yaml', 'utf8'),
  readFile('server.mjs', 'utf8')
]);

const checks = [
  ['accessible page landmark', () => assert.match(html, /id="app"/)],
  ['responsive layout rules', () => assert.match(css, /@media \(max-width: 720px\)/)],
  ['custom dropdown component', () => assert.match(js, /function customSelect/)],
  ['custom dropdown keyboard support', () => assert.match(js, /ArrowDown.*ArrowUp/)],
  ['custom dropdown visual design', () => assert.match(css, /\.custom-select-menu/)],
  ['premium action links', () => assert.match(css, /\.view-all-action/)],
  ['completed hero dashboard preview', () => assert.match(js, /Good morning, Daniel\./)],
  ['reduced motion support', () => assert.match(css, /prefers-reduced-motion/)],
  ['output escaping', () => assert.match(js, /replaceAll\('<', '&lt;'\)/)],
  ['protected-route check', () => assert.match(js, /function requireAuth/)],
  ['complaint form workflow', () => assert.match(js, /complaint-form/)],
  ['role-specific admin view', () => assert.match(js, /adminDashboard/)],
  ['row-level security enabled', () => assert.match(schema, /enable row level security/gi)],
  ['student ownership policy', () => assert.match(schema, /Students read their own complaints/)],
  ['Render SPA rewrite', () => assert.match(render, /destination: \/index\.html/)],
  ['Render Node web service', () => assert.match(render, /name: campusvoice-web[\s\S]*runtime: node/)],
  ['managed PostgreSQL binding', () => assert.match(render, /fromDatabase:[\s\S]*campusvoice-db/)],
  ['password hashing', () => assert.match(server, /bcrypt\.hash/)],
  ['parameterized database queries', () => assert.match(server, /where email = \$1/)],
  ['CSRF enforcement', () => assert.match(server, /x-csrf-token/)],
  ['secure session cookie', () => assert.match(server, /HttpOnly; SameSite=Strict/)],
  ['server-side role enforcement', () => assert.match(server, /role !== 'admin'/)]
];

for (const [name, run] of checks) {
  run();
  console.log(`✓ ${name}`);
}
console.log(`\n${checks.length} smoke checks passed.`);
