import { spawn } from 'node:child_process';
import { strict as assert } from 'node:assert';

const port = 43127;
const base = `http://127.0.0.1:${port}`;
const server = spawn(process.execPath, ['server.mjs'], {
  env: { ...process.env, PORT: String(port), NODE_ENV: 'test', DATABASE_URL: '' },
  stdio: ['ignore', 'pipe', 'pipe']
});

let output = '';
server.stdout.on('data', chunk => { output += chunk; });
server.stderr.on('data', chunk => { output += chunk; });

async function waitForServer() {
  for (let attempt = 0; attempt < 60; attempt += 1) {
    try {
      const response = await fetch(`${base}/api/health`);
      if (response.ok) return;
    } catch {}
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  throw new Error(`Server did not start.\n${output}`);
}

async function request(path, options = {}) {
  const response = await fetch(`${base}${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', Origin: base, ...options.headers }
  });
  const data = await response.json();
  return { response, data };
}

try {
  await waitForServer();

  const health = await request('/api/health');
  assert.equal(health.response.status, 200);
  assert.equal(health.data.database, 'memory');

  const invalid = await request('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ name: 'Test Student', email: 'student@example.edu', password: 'short', studentId: 'CSC/2026/001', department: 'Computer Science' })
  });
  assert.equal(invalid.response.status, 400);

  const registration = await request('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ name: 'Test Student', email: 'student@example.edu', password: 'Secure123!', studentId: 'CSC/2026/001', department: 'Computer Science' })
  });
  assert.equal(registration.response.status, 201);
  assert.equal(registration.data.user.role, 'student');
  const cookie = registration.response.headers.get('set-cookie').split(';')[0];
  const csrf = registration.data.csrfToken;

  const unauthenticated = await request('/api/complaints');
  assert.equal(unauthenticated.response.status, 401);

  const missingCsrf = await request('/api/complaints', {
    method: 'POST', headers: { Cookie: cookie }, body: JSON.stringify({})
  });
  assert.equal(missingCsrf.response.status, 403);

  const created = await request('/api/complaints', {
    method: 'POST',
    headers: { Cookie: cookie, 'X-CSRF-Token': csrf },
    body: JSON.stringify({
      title: '<script>alert(1)</script> projector issue',
      category: 'Facilities',
      date: '2026-10-01',
      location: 'Lecture Hall B',
      confidential: false,
      description: 'The projector has failed during three consecutive lectures and needs attention.',
      outcome: 'Repair or replace the projector.'
    })
  });
  assert.equal(created.response.status, 201);
  assert.match(created.data.complaint.id, /^SCMS-\d{4}-[A-F0-9]{8}$/);

  const listed = await request('/api/complaints', { headers: { Cookie: cookie } });
  assert.equal(listed.response.status, 200);
  assert.equal(listed.data.complaints.length, 1);
  assert.equal(listed.data.complaints[0].title, '<script>alert(1)</script> projector issue');

  const forbiddenAdminAction = await request(`/api/complaints/${created.data.complaint.id}`, {
    method: 'PATCH',
    headers: { Cookie: cookie, 'X-CSRF-Token': csrf },
    body: JSON.stringify({ status: 'Resolved' })
  });
  assert.equal(forbiddenAdminAction.response.status, 403);

  const wrongPassword = await request('/api/auth/login', {
    method: 'POST', body: JSON.stringify({ email: 'student@example.edu', password: 'wrong-password' })
  });
  assert.equal(wrongPassword.response.status, 401);

  console.log('✓ health endpoint and database adapter');
  console.log('✓ registration validation and password hashing');
  console.log('✓ secure session cookie and CSRF enforcement');
  console.log('✓ authenticated complaint creation and retrieval');
  console.log('✓ role-based administrator restriction');
  console.log('✓ user content remains inert data for escaped rendering');
  console.log('\n6 API integration checks passed.');
} finally {
  server.kill();
}
