import { cp, mkdir, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const root = process.cwd();
const output = join(root, 'dist');
await rm(output, { recursive: true, force: true });
await mkdir(output, { recursive: true });

for (const file of ['index.html', 'styles.css', 'app.js']) {
  await cp(join(root, file), join(output, file));
}
await writeFile(join(output, '_redirects'), '/* /index.html 200\n');
console.log('Built static site in dist/');

