const app = document.querySelector('#app');
const toastRegion = document.querySelector('#toast-region');

const seedComplaints = [
  {
    id: 'SCMS-2026-00421',
    title: 'Lecture hall projector has been unavailable',
    category: 'Facilities',
    department: 'Works & Maintenance',
    priority: 'Medium',
    status: 'In Progress',
    date: '2026-09-28',
    updated: '2 hours ago',
    description: 'The projector in Lecture Hall B has not worked during three consecutive classes. This makes it difficult to follow diagrams and presentation materials.',
    outcome: 'Repair or replace the projector and confirm when the hall is ready for use.'
  },
  {
    id: 'SCMS-2026-00398',
    title: 'Incorrect course registration fee displayed',
    category: 'Fees & Payments',
    department: 'Bursary',
    priority: 'High',
    status: 'Under Review',
    date: '2026-09-24',
    updated: 'Yesterday',
    description: 'My portal shows an additional course registration charge after payment was completed.',
    outcome: 'Review the payment record and correct the balance.'
  },
  {
    id: 'SCMS-2026-00357',
    title: 'Result missing from student portal',
    category: 'Academic',
    department: 'Examinations & Records',
    priority: 'Medium',
    status: 'Resolved',
    date: '2026-09-15',
    updated: '5 days ago',
    description: 'My CSC 305 result was not shown even though I completed the examination.',
    outcome: 'Restore the verified result on the student portal.'
  }
];

const state = {
  user: null,
  complaints: [],
  navOpen: false,
  filter: 'All',
  query: ''
};
let csrfToken = null;
let initialized = false;

const e = (value = '') => String(value)
  .replaceAll('&', '&amp;')
  .replaceAll('<', '&lt;')
  .replaceAll('>', '&gt;')
  .replaceAll('"', '&quot;')
  .replaceAll("'", '&#039;');

const icons = {
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/>',
  home: '<path d="m3 11 9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M9 20v-6h6v6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M8 13h8M8 17h5"/>',
  user: '<path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/>',
  lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  test: '<path d="m9 11 3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  chart: '<path d="M3 3v18h18"/><path d="m7 16 4-5 4 3 5-7"/>',
  bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  send: '<path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z"/>',
  inbox: '<path d="M4 4h16v16H4z"/><path d="M4 13h4l2 3h4l2-3h4"/>',
  users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
  arrow: '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>'
};

function icon(name, extra = '') {
  return `<svg class="icon ${extra}" viewBox="0 0 24 24" aria-hidden="true">${icons[name] || icons.file}</svg>`;
}

function selectTone(value, index) {
  const tones = {
    All: 'indigo', Submitted: 'indigo', 'Under Review': 'amber', 'In Progress': 'violet', Resolved: 'green',
    Academic: 'indigo', 'Fees & Payments': 'amber', Examinations: 'violet', Facilities: 'green',
    'Harassment or Misconduct': 'rose', 'Student Services': 'cyan', Security: 'navy', Other: 'slate',
    'Computer Science': 'indigo', Engineering: 'amber', 'Business Administration': 'green', 'Social Sciences': 'violet'
  };
  return tones[value] || ['indigo', 'amber', 'green', 'violet'][index % 4];
}

function customSelect({ id, name, options, value = '', placeholder = 'Select an option', ariaLabel = '', required = false, compact = false }) {
  const normalized = options.map((option, index) => typeof option === 'string'
    ? { value: option, label: option, meta: '', tone: selectTone(option, index) }
    : { ...option, tone: option.tone || selectTone(option.value, index) });
  const selected = normalized.find(option => option.value === value);
  const selectedTone = selected?.tone || 'slate';
  return `<div class="custom-select ${compact ? 'custom-select-compact' : ''}" data-custom-select ${required ? 'data-required="true"' : ''}>
    <input type="hidden" id="${e(id)}-input" name="${e(name)}" value="${e(value)}">
    <button class="custom-select-trigger ${selected ? '' : 'is-placeholder'}" id="${e(id)}" type="button" data-select-trigger aria-haspopup="listbox" aria-expanded="false" aria-controls="${e(id)}-list" ${ariaLabel ? `aria-label="${e(ariaLabel)}"` : ''}>
      <span class="custom-select-value"><span class="custom-select-marker tone-${selectedTone}"></span><span data-select-label>${e(selected?.label || placeholder)}</span></span>
      <span class="custom-select-chevron">${icon('arrow')}</span>
    </button>
    <div class="custom-select-menu" id="${e(id)}-list" role="listbox" aria-labelledby="${e(id)}" tabindex="-1">
      <div class="custom-select-menu-label">Choose an option</div>
      ${normalized.map(option => `<button class="custom-select-option" type="button" role="option" data-select-option data-value="${e(option.value)}" data-label="${e(option.label)}" data-tone="${e(option.tone)}" aria-selected="${option.value === value}"><span class="custom-select-marker tone-${e(option.tone)}"></span><span class="custom-select-option-copy"><strong>${e(option.label)}</strong>${option.meta ? `<small>${e(option.meta)}</small>` : ''}</span><span class="custom-select-check">${icon('check')}</span></button>`).join('')}
    </div>
    <span class="custom-select-error" hidden>Please choose an option.</span>
  </div>`;
}

function viewAllAction() {
  return `<button class="view-all-action" data-route="complaints"><span>View all</span><span class="view-all-icon">${icon('arrow')}</span></button>`;
}

async function api(path, options = {}) {
  const headers = { Accept: 'application/json', ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...options.headers };
  if (csrfToken && options.method && !['GET', 'HEAD'].includes(options.method)) headers['X-CSRF-Token'] = csrfToken;
  const response = await fetch(`/api${path}`, { credentials: 'same-origin', ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'The request could not be completed.');
  return data;
}

async function loadComplaints() {
  if (!state.user) {
    state.complaints = [];
    return;
  }
  const data = await api('/complaints');
  state.complaints = data.complaints;
}

function setBusy(form, busy, label = 'Please wait…') {
  const submit = form.querySelector('[type="submit"]');
  if (!submit) return;
  if (busy) {
    submit.dataset.originalLabel = submit.innerHTML;
    submit.textContent = label;
    submit.disabled = true;
  } else {
    submit.innerHTML = submit.dataset.originalLabel || submit.innerHTML;
    submit.disabled = false;
  }
}

function go(route) {
  state.navOpen = false;
  location.hash = route;
}

function toast(title, message) {
  const node = document.createElement('div');
  node.className = 'toast';
  node.innerHTML = `<div class="toast-icon">${icon('check')}</div><div><strong>${e(title)}</strong><small>${e(message)}</small></div>`;
  toastRegion.append(node);
  setTimeout(() => node.remove(), 3800);
}

function topbar(publicOnly = false) {
  const loggedIn = Boolean(state.user);
  return `
    <header class="topbar">
      <nav class="container nav ${state.navOpen ? 'open' : ''}" aria-label="Main navigation">
        <button class="brand" data-route="${loggedIn ? (state.user.role === 'admin' ? 'admin' : 'dashboard') : 'home'}" aria-label="CampusVoice home">
          <span class="brand-mark">${icon('shield')}</span>
          <span class="brand-name">Campus<span>Voice</span></span>
        </button>
        ${publicOnly ? `
          <div class="nav-links">
            <button class="nav-link" data-scroll="how">How it works</button>
            <button class="nav-link" data-route="security">Security</button>
            <button class="nav-link" data-scroll="contact">Support</button>
          </div>` : ''}
        <div class="nav-actions">
          ${loggedIn ? `
            <button class="icon-btn" aria-label="Notifications">${icon('bell')}</button>
            <button class="btn btn-light btn-sm" data-route="profile">${e(state.user.name.split(' ')[0])}</button>
          ` : `
            <button class="btn btn-ghost" data-route="login">Log in</button>
            <button class="nav-cta" data-route="register"><span>Create account</span><span class="nav-cta-icon">${icon('arrow')}</span></button>
          `}
          ${publicOnly ? `<button class="mobile-toggle" data-action="toggle-nav" aria-label="Toggle menu">${icon('menu')}</button>` : ''}
        </div>
      </nav>
    </header>`;
}

function footer() {
  return `<footer class="footer" id="contact"><div class="container footer-inner"><div class="brand"><span class="brand-mark">${icon('shield')}</span><span class="brand-name">Campus<span>Voice</span></span></div><span>Student concerns, handled with clarity and care.</span><span>© 2026 CampusVoice</span></div></footer>`;
}

function landing() {
  return `${topbar(true)}
    <main id="main">
      <section class="hero">
        <div class="container hero-grid">
          <div class="hero-copy">
            <span class="eyebrow">A clearer path to resolution</span>
            <h1>Your concern deserves <span>a real response.</span></h1>
            <p>Submit complaints securely, follow every update, and know exactly when action has been taken—without chasing offices or losing paperwork.</p>
            <div class="hero-actions">
              <button class="btn btn-primary" data-route="register">Submit a complaint ${icon('send')}</button>
              <button class="btn btn-light" data-route="login">Track an existing complaint</button>
            </div>
            <div class="trust-row"><span>Private by design</span><span>Transparent updates</span><span>Works on every device</span></div>
          </div>
          <div class="hero-visual" aria-label="CampusVoice student dashboard preview">
            <div class="dashboard-preview">
              <div class="preview-browser"><i></i><i></i><i></i></div>
              <div class="preview-inner">
                <div class="preview-side"><div class="preview-logo"></div><span></span><span></span><span></span><span></span></div>
                <div class="preview-main">
                  <div class="preview-welcome"><div><small>Student dashboard</small><strong>Good morning, Daniel.</strong></div><span class="preview-avatar">DA</span></div>
                  <div class="preview-metrics"><div class="preview-metric featured"><small>Open cases</small><b>03</b></div><div class="preview-metric"><small>In progress</small><b>01</b></div><div class="preview-metric"><small>Resolved</small><b>08</b></div></div>
                  <div class="preview-ticket"><div class="preview-list-head"><strong>Recent complaints</strong><span>View all</span></div><div class="preview-ticket-row"><div class="preview-dot">${icon('file')}</div><div class="preview-lines"><b>Library Wi-Fi interruptions</b><i>Facilities · Updated today</i></div><span class="preview-status progress">In progress</span></div><div class="preview-ticket-row"><div class="preview-dot amber">${icon('clock')}</div><div class="preview-lines"><b>Course fee discrepancy</b><i>Bursary · Updated yesterday</i></div><span class="preview-status review">Review</span></div><div class="preview-ticket-row"><div class="preview-dot green">${icon('check')}</div><div class="preview-lines"><b>Missing portal result</b><i>Academic · Resolved</i></div><span class="preview-status resolved">Resolved</span></div></div>
                </div>
              </div>
            </div>
            <div class="float-card one"><span class="float-icon">✓</span><div><strong>Issue resolved</strong><small>Just now</small></div></div>
            <div class="float-card two"><span class="float-icon">03</span><div><strong>Active cases</strong><small>All on track</small></div></div>
          </div>
        </div>
      </section>
      <section class="section" id="how">
        <div class="container"><div class="section-heading center"><span class="eyebrow">Simple by design</span><h2>From concern to resolution in three clear steps.</h2><p>No confusing forms. No silent handoffs. Just a visible process that keeps everyone accountable.</p></div>
          <div class="steps">
            ${step('01', 'file', 'Tell us what happened', 'Use a short guided form to describe your concern and attach supporting evidence.')}
            ${step('02', 'eye', 'Follow the response', 'Track assignment, progress, and official updates from one private dashboard.')}
            ${step('03', 'check', 'Receive a resolution', 'Review the documented outcome and confirm when the issue has been addressed.')}
          </div>
        </div>
      </section>
      <section class="section section-dark"><div class="container security-panel"><div class="security-copy"><span class="eyebrow">Security, built in</span><h2>Private information stays in the right hands.</h2><p>CampusVoice is designed around verified access, least-privilege permissions, safe input handling, and a complete record of important actions.</p><button class="btn btn-light" data-route="security">Explore our security approach</button></div><div class="security-list">${securityItems()}</div></div></section>
      <section class="section section-white"><div class="container"><div class="cta-panel"><div><h2>Ready to be heard?</h2><p>Create a secure report in minutes and follow every step toward resolution.</p></div><button class="btn" data-route="register">Start your complaint ${icon('send')}</button></div></div></section>
    </main>${footer()}`;
}

function step(number, iconName, title, copy) {
  return `<article class="step-card"><span class="step-number">${number}</span><div class="step-icon">${icon(iconName)}</div><h3>${title}</h3><p>${copy}</p></article>`;
}

function securityItems() {
  return [
    ['Verified access', 'Authentication is required before protected records are shown.'],
    ['Role permissions', 'Students and administrators receive only the access they need.'],
    ['Safe data handling', 'Validated inputs and protected database operations reduce risk.'],
    ['Activity records', 'Important case actions can be reviewed in an audit history.']
  ].map(([title, copy]) => `<div class="security-item"><span class="security-check">✓</span><div><b>${title}</b><small>${copy}</small></div></div>`).join('');
}

function authPage(mode) {
  const register = mode === 'register';
  return `${topbar(false)}<main id="main" class="auth-page"><section class="auth-art"><div class="auth-art-inner"><span class="eyebrow">CampusVoice</span><h1>${register ? 'A safer way to speak up.' : 'Your cases. Your updates. One secure place.'}</h1><p>${register ? 'Create your private student account to report concerns and follow the response without unnecessary delays.' : 'Sign in to continue tracking your complaints and reviewing official responses.'}</p><div class="auth-quote"><strong>Clear process. Visible accountability.</strong><p class="small">Every complaint receives a unique reference and a status history you can follow.</p></div></div></section><section class="auth-content"><form class="auth-form" id="${mode}-form" novalidate><span class="eyebrow">${register ? 'Get started' : 'Welcome back'}</span><h2>${register ? 'Create your account' : 'Sign in to continue'}</h2><p>${register ? 'Use your institutional details to begin.' : 'Enter your account details below.'}</p><div class="auth-fields">
    ${register ? `<div class="form-group"><label for="name">Full name <span class="required">*</span></label><input id="name" name="name" autocomplete="name" placeholder="e.g. Ada Okafor" required></div><div class="form-group"><label for="student-id">Student ID <span class="required">*</span></label><input id="student-id" name="studentId" placeholder="e.g. CSC/2023/1042" required></div>` : ''}
    <div class="form-group"><label for="email">Institutional email <span class="required">*</span></label><input id="email" name="email" type="email" autocomplete="email" placeholder="name@university.edu" required></div>
    <div class="form-group"><label for="password">Password <span class="required">*</span></label><div class="password-wrap"><input id="password" name="password" type="password" autocomplete="${register ? 'new-password' : 'current-password'}" minlength="8" placeholder="At least 8 characters" required><button type="button" class="show-password" data-action="show-password">Show</button></div></div>
    ${register ? `<div class="form-group"><label for="department">Department</label>${customSelect({ id: 'department', name: 'department', value: 'Computer Science', options: [
      { value: 'Computer Science', label: 'Computer Science', meta: 'Faculty of Science' },
      { value: 'Engineering', label: 'Engineering', meta: 'Faculty of Engineering' },
      { value: 'Business Administration', label: 'Business Administration', meta: 'Faculty of Management' },
      { value: 'Social Sciences', label: 'Social Sciences', meta: 'Faculty of Social Sciences' }
    ] })}</div><label class="choice-card"><input type="checkbox" name="terms" required><span><strong>I agree to responsible use</strong><span class="field-hint">I understand that intentionally false reports may be reviewed.</span></span></label>` : ''}
  </div><button class="btn btn-primary btn-block" type="submit">${register ? 'Create secure account' : 'Sign in'}</button><div class="auth-switch"><span>${register ? 'Already registered?' : 'New to CampusVoice?'}</span><button type="button" class="auth-switch-link" data-route="${register ? 'login' : 'register'}">${register ? 'Sign in' : 'Create an account'} ${icon('arrow')}</button></div>
  ${!register ? `<div class="demo-box"><strong>Secure account access</strong><br>Your password is verified by the server and your session is stored in a protected, HTTP-only cookie.</div>` : ''}
  </form></section></main>`;
}

function sidebar(active) {
  const admin = state.user?.role === 'admin';
  const links = admin ? [
    ['admin', 'home', 'Overview'], ['complaints', 'inbox', 'All complaints'], ['testing', 'test', 'Testing'], ['security', 'lock', 'Security'], ['profile', 'user', 'Profile']
  ] : [
    ['dashboard', 'home', 'Overview'], ['new', 'plus', 'New complaint'], ['complaints', 'file', 'My complaints'], ['security', 'lock', 'Security'], ['profile', 'user', 'Profile']
  ];
  return `<aside class="sidebar"><div class="sidebar-label">Workspace</div>${links.map(([route, iconName, label]) => `<button class="side-link ${active === route ? 'active' : ''}" data-route="${route}">${icon(iconName)}<span>${label}</span></button>`).join('')}<button class="side-link" data-action="logout">${icon('logout')}<span>Log out</span></button><div class="sidebar-help"><strong>Need help?</strong><p>Contact student affairs if your concern involves immediate safety.</p><button class="btn btn-light btn-sm">Get support</button></div></aside>`;
}

function appShell(content, active) {
  return `${topbar(false)}<div class="app-layout">${sidebar(active)}<main id="main" class="main-content">${content}</main></div>`;
}

function dashboard() {
  const counts = countStatuses();
  return appShell(`<div class="page-head"><div><span class="eyebrow">Student workspace</span><h1>Good morning, ${e(state.user.name.split(' ')[0])}.</h1><p>Here is the latest activity across your submitted concerns.</p></div><button class="btn btn-primary" data-route="new">${icon('plus')} New complaint</button></div>${metricCards([
    ['Total complaints', state.complaints.length, 'All submitted cases', 'file'],
    ['Awaiting review', counts.review, 'Needs administrative action', 'clock'],
    ['In progress', counts.progress, 'Currently being handled', 'chart'],
    ['Resolved', counts.resolved, 'Completed successfully', 'check']
  ])}<div class="content-grid"><section class="panel"><div class="panel-head"><h2>Recent complaints</h2>${viewAllAction()}</div>${complaintTable(state.complaints.slice(0, 4))}</section><aside class="panel"><div class="panel-head"><h3>Recent activity</h3></div><div class="panel-body"><div class="activity-list"><div class="activity"><span class="activity-icon">${icon('check')}</span><p><strong>Complaint moved to In Progress</strong><br><small>Projector issue · 2 hours ago</small></p></div><div class="activity"><span class="activity-icon">${icon('file')}</span><p><strong>Response received from Bursary</strong><br><small>Fee discrepancy · Yesterday</small></p></div><div class="activity"><span class="activity-icon">${icon('bell')}</span><p><strong>Resolution confirmed</strong><br><small>Missing result · 5 days ago</small></p></div></div></div></aside></div>`, 'dashboard');
}

function adminDashboard() {
  return appShell(`<div class="page-head"><div><span class="eyebrow">Administration</span><h1>Complaint operations</h1><p>Review workload, spot urgent cases, and keep resolution moving.</p></div><button class="btn btn-primary" data-route="complaints">Open assignment queue</button></div>${metricCards([
    ['Open cases', '24', '+4 this week', 'inbox'], ['Unassigned', '7', 'Requires attention', 'users'], ['Overdue', '3', 'Past target date', 'clock'], ['Resolution rate', '91%', 'Last 30 days', 'chart']
  ])}<div class="content-grid"><section class="panel"><div class="panel-head"><h2>Priority queue</h2>${viewAllAction()}</div>${complaintTable(state.complaints)}</section><aside class="panel"><div class="panel-head"><h3>Workload by status</h3></div><div class="panel-body"><div class="meta-list"><div class="meta-row"><span>Under review</span><strong>8 cases</strong></div><div class="meta-row"><span>Assigned</span><strong>5 cases</strong></div><div class="meta-row"><span>In progress</span><strong>11 cases</strong></div><div class="meta-row"><span>Awaiting student</span><strong>2 cases</strong></div></div></div></aside></div>`, 'admin');
}

function metricCards(items) {
  return `<section class="metrics">${items.map(([label, value, foot, iconName]) => `<article class="metric-card"><div class="metric-top"><span>${label}</span><span class="metric-icon">${icon(iconName)}</span></div><div class="metric-value">${value}</div><div class="metric-foot">${foot}</div></article>`).join('')}</section>`;
}

function countStatuses() {
  return {
    review: state.complaints.filter(c => ['Submitted', 'Under Review'].includes(c.status)).length,
    progress: state.complaints.filter(c => c.status === 'In Progress').length,
    resolved: state.complaints.filter(c => ['Resolved', 'Closed'].includes(c.status)).length
  };
}

function statusClass(status) {
  return status === 'Submitted' ? 'submitted' : status === 'Under Review' ? 'review' : status === 'In Progress' ? 'progress' : 'resolved';
}

function complaintTable(items) {
  if (!items.length) return `<div class="empty"><div class="empty-icon">${icon('search')}</div><h3>No complaints found</h3><p>Try a different search or remove the selected filter.</p></div>`;
  return `<div class="table-wrap"><table><thead><tr><th>Complaint</th><th>Category</th><th>Status</th><th>Updated</th></tr></thead><tbody>${items.map(c => `<tr data-complaint="${e(c.id)}" tabindex="0"><td><div class="ticket-title">${e(c.title)}</div><div class="ticket-ref">${e(c.id)}</div></td><td>${e(c.category)}</td><td><span class="status status-${statusClass(c.status)}">${e(c.status)}</span></td><td class="muted">${e(c.updated)}</td></tr>`).join('')}</tbody></table></div>`;
}

function complaintsPage() {
  const query = state.query.toLowerCase();
  const filtered = state.complaints.filter(c => (state.filter === 'All' || c.status === state.filter) && [c.title, c.id, c.category, c.department].join(' ').toLowerCase().includes(query));
  const statusSelect = customSelect({ id: 'status-filter', name: 'statusFilter', value: state.filter, compact: true, ariaLabel: 'Filter by status', options: [
    { value: 'All', label: 'All complaints', meta: 'Every status' },
    { value: 'Submitted', label: 'Submitted', meta: 'Newly received' },
    { value: 'Under Review', label: 'Under review', meta: 'Awaiting a decision' },
    { value: 'In Progress', label: 'In progress', meta: 'Currently being handled' },
    { value: 'Resolved', label: 'Resolved', meta: 'Completed cases' }
  ] });
  return appShell(`<div class="page-head"><div><span class="eyebrow">Case register</span><h1>${state.user.role === 'admin' ? 'All complaints' : 'My complaints'}</h1><p>Search by reference, subject, category, or responsible department.</p></div>${state.user.role === 'student' ? `<button class="btn btn-primary" data-route="new">${icon('plus')} New complaint</button>` : ''}</div><div class="toolbar"><div class="search-box"><span class="search-icon">${icon('search')}</span><input id="complaint-search" value="${e(state.query)}" placeholder="Search complaints..."></div>${statusSelect}</div><section class="panel">${complaintTable(filtered)}</section>`, 'complaints');
}

function newComplaint() {
  const categorySelect = customSelect({ id: 'category', name: 'category', required: true, placeholder: 'Choose a complaint category', options: [
    { value: 'Academic', label: 'Academic', meta: 'Teaching, supervision or coursework' },
    { value: 'Fees & Payments', label: 'Fees & payments', meta: 'Charges, receipts or account balances' },
    { value: 'Examinations', label: 'Examinations', meta: 'Results, schedules or assessment issues' },
    { value: 'Facilities', label: 'Facilities', meta: 'Buildings, equipment or campus services' },
    { value: 'Harassment or Misconduct', label: 'Harassment or misconduct', meta: 'Behaviour requiring confidential review' },
    { value: 'Student Services', label: 'Student services', meta: 'Registration, welfare or support' },
    { value: 'Security', label: 'Security', meta: 'Safety incidents or access concerns' },
    { value: 'Other', label: 'Other', meta: 'Anything not covered above' }
  ] });
  return appShell(`<div class="page-head"><div><span class="eyebrow">New complaint</span><h1>Tell us what happened.</h1><p>Provide clear details so the right team can respond quickly.</p></div></div><form class="form-card" id="complaint-form" novalidate><section class="form-section"><h2>1. Complaint details</h2><p>Choose the category that best matches your concern.</p><div class="form-grid"><div class="form-group full"><label for="title">Short title <span class="required">*</span></label><input id="title" name="title" maxlength="120" placeholder="Summarise the issue in one sentence" required><span class="field-hint">Avoid including passwords or financial details.</span></div><div class="form-group"><label for="category">Category <span class="required">*</span></label>${categorySelect}</div><div class="form-group"><label for="incident-date">Incident date <span class="required">*</span></label><input id="incident-date" name="date" type="date" max="${new Date().toISOString().slice(0,10)}" required></div><div class="form-group full"><label for="location">Location</label><input id="location" name="location" placeholder="e.g. Lecture Hall B or Student Portal"></div></div></section><section class="form-section"><h2>2. Describe the concern</h2><p>Stick to the relevant facts. You can add supporting context below.</p><div class="form-grid"><div class="form-group full"><label for="description">What happened? <span class="required">*</span></label><textarea id="description" name="description" minlength="30" maxlength="2000" placeholder="Describe what happened, when it occurred, and anyone already contacted..." required></textarea><span class="field-hint">Minimum 30 characters.</span></div><div class="form-group full"><label for="outcome">What outcome would you consider fair?</label><textarea id="outcome" name="outcome" maxlength="800" placeholder="Tell us what would help resolve this concern..."></textarea></div></div></section><section class="form-section"><h2>3. Evidence and privacy</h2><p>Attachments are optional. Do not upload unrelated sensitive documents.</p><div class="form-grid"><div class="form-group full"><div class="file-drop"><div><strong>Attach supporting evidence</strong><div class="field-hint">PDF, JPG or PNG · maximum 5 MB each</div><input type="file" name="evidence" accept=".pdf,.jpg,.jpeg,.png"></div></div></div><div class="form-group full"><label class="choice-card"><input type="checkbox" name="confidential"><span><strong>Mark this complaint as confidential</strong><span class="field-hint">Visibility will be limited to specifically authorized handlers.</span></span></label></div></div></section><div class="form-actions"><button type="button" class="btn btn-light" data-route="dashboard">Cancel</button><button class="btn btn-primary" type="submit">Submit complaint ${icon('send')}</button></div></form>`, 'new');
}

function complaintDetail(id) {
  const complaint = state.complaints.find(c => c.id === id);
  if (!complaint) return appShell(`<div class="empty"><div class="empty-icon">${icon('search')}</div><h3>Complaint not found</h3><p>The case may have been removed or you may not have access to it.</p><button class="btn btn-light" data-route="complaints">Back to complaints</button></div>`, 'complaints');
  const adminStatus = state.user.role === 'admin' ? `<section class="panel" style="margin-top:20px"><div class="panel-head"><h3>Administrator action</h3></div><div class="panel-body"><div class="form-group"><label for="complaint-status">Update case status</label>${customSelect({ id: 'complaint-status', name: 'status', value: complaint.status, options: ['Submitted', 'Under Review', 'Assigned', 'In Progress', 'Resolved', 'Closed', 'Reopened'] })}</div></div></section>` : '';
  return appShell(`<div class="page-head"><div><span class="eyebrow">${e(complaint.id)}</span><h1>${e(complaint.title)}</h1><p>Submitted on ${e(new Date(complaint.date).toLocaleDateString('en-NG', { dateStyle: 'long' }))}</p></div><span class="status status-${statusClass(complaint.status)}">${e(complaint.status)}</span></div><div class="detail-grid"><section class="panel"><div class="detail-block"><h2>Complaint description</h2><p>${e(complaint.description)}</p></div><div class="detail-block"><h2>Requested outcome</h2><p>${e(complaint.outcome || 'No preferred outcome was provided.')}</p></div><div class="detail-block"><h2>Official response</h2><div class="notice"><span>${icon('shield')}</span><div><strong>Your complaint is being handled</strong><div class="small">The responsible department is reviewing the available information. You will be notified when a formal response is added.</div></div></div></div></section><aside><section class="panel"><div class="panel-head"><h3>Case details</h3></div><div class="panel-body"><div class="meta-list"><div class="meta-row"><span>Category</span><strong>${e(complaint.category)}</strong></div><div class="meta-row"><span>Department</span><strong>${e(complaint.department)}</strong></div><div class="meta-row"><span>Priority</span><strong>${e(complaint.priority)}</strong></div><div class="meta-row"><span>Reference</span><strong>${e(complaint.id)}</strong></div></div></div></section>${adminStatus}<section class="panel" style="margin-top:20px"><div class="panel-head"><h3>Status timeline</h3></div><div class="panel-body"><div class="timeline"><div class="timeline-item complete"><span class="timeline-dot"></span><div class="timeline-content"><strong>Submitted</strong><small>${e(complaint.date)}</small></div></div><div class="timeline-item ${complaint.status !== 'Submitted' ? 'complete' : 'current'}"><span class="timeline-dot"></span><div class="timeline-content"><strong>Under review</strong><small>Initial checks completed</small></div></div><div class="timeline-item ${complaint.status === 'In Progress' ? 'current' : ['Resolved','Closed'].includes(complaint.status) ? 'complete' : ''}"><span class="timeline-dot"></span><div class="timeline-content"><strong>In progress</strong><small>Assigned to a department</small></div></div><div class="timeline-item ${['Resolved','Closed'].includes(complaint.status) ? 'complete' : ''}"><span class="timeline-dot"></span><div class="timeline-content"><strong>Resolved</strong><small>Final outcome recorded</small></div></div></div></div></section></aside></div>`, 'complaints');
}

function securityPage() {
  const cards = [
    ['lock', 'Secure authentication', 'Protected areas require a verified server session. Passwords are hashed with bcrypt and never stored in plain text.'],
    ['users', 'Role-based access', 'Students, staff, and administrators receive separate permissions with server-side policy checks.'],
    ['shield', 'Database protection', 'Row-Level Security keeps students limited to their own complaints and authorized staff within their scope.'],
    ['test', 'Validated input', 'Required fields, lengths, dates, attachments, and expected values are checked before processing.'],
    ['file', 'Safe content display', 'User-entered text is escaped before it is inserted into the interface, reducing cross-site scripting risk.'],
    ['eye', 'Audit visibility', 'Administrative assignments, status changes, and resolutions are designed to leave a reviewable record.']
  ];
  const content = `<div class="page-head"><div><span class="eyebrow">Trust centre</span><h1>Security is part of the system.</h1><p>How CampusVoice protects student information and controls access.</p></div></div><div class="notice" style="margin-bottom:22px"><span>${icon('shield')}</span><div><strong>Active server protection</strong><div class="small">Authentication, PostgreSQL storage, role checks, CSRF protection, rate limiting, secure cookies, input validation, and parameterized database queries are enforced by the web service.</div></div></div><div class="security-grid">${cards.map(([i,title,copy]) => `<article class="security-card"><div class="step-icon">${icon(i)}</div><h3>${title}</h3><p>${copy}</p></article>`).join('')}</div>`;
  return state.user ? appShell(content, 'security') : `${topbar(true)}<main id="main" class="page"><div class="container">${content}</div></main>${footer()}`;
}

function testingPage() {
  const tests = [
    ['Registration and login', 'Required fields, email format, password length, and role entry points.'],
    ['Complaint submission', 'Successful creation, unique references, confirmation, and dashboard display.'],
    ['Form validation', 'Missing values, invalid dates, text limits, and attachment restrictions.'],
    ['Access control', 'Student/admin separation and protected-route redirects.'],
    ['Search and filtering', 'Reference, title, category, department, and status matching.'],
    ['Responsive layout', 'Navigation, cards, tables, and forms from 360px through desktop.'],
    ['Safe rendering', 'User-entered content displays as text instead of executable markup.'],
    ['Error handling', 'Empty results, invalid form states, and missing case fallbacks.']
  ];
  return appShell(`<div class="page-head"><div><span class="eyebrow">Quality assurance</span><h1>Testing evidence</h1><p>Automated and manual checks across the interface, API, access control, and database layer.</p></div><span class="status status-resolved">8 checks defined</span></div><div class="test-grid">${tests.map(([title,copy]) => `<article class="test-card"><span class="test-result">✓</span><div><strong>${title}</strong><p>${copy}</p></div></article>`).join('')}</div>`, 'testing');
}

function profilePage() {
  const u = state.user;
  return appShell(`<div class="page-head"><div><span class="eyebrow">Account</span><h1>Your profile</h1><p>Manage your personal details and account preferences.</p></div><button class="btn btn-light" data-action="logout">${icon('logout')} Sign out</button></div><section class="panel"><div class="detail-block profile-head"><div class="avatar">${e(u.name.split(' ').map(n => n[0]).join('').slice(0,2).toUpperCase())}</div><div><h2 style="margin-bottom:5px">${e(u.name)}</h2><p style="margin:0">${e(u.email)}</p><span class="status status-resolved" style="margin-top:9px">${e(u.role)}</span></div></div><form class="detail-block" id="profile-form"><div class="form-grid"><div class="form-group"><label for="profile-name">Full name</label><input id="profile-name" name="name" value="${e(u.name)}"></div><div class="form-group"><label for="profile-email">Email</label><input id="profile-email" value="${e(u.email)}" disabled></div><div class="form-group"><label for="profile-id">Student ID</label><input id="profile-id" value="${e(u.studentId || 'Administrator')}" disabled></div><div class="form-group"><label for="profile-department">Department</label><input id="profile-department" value="${e(u.department || 'Student Affairs')}" disabled></div></div><div class="form-actions" style="margin-top:22px"><button class="btn btn-primary" type="submit">Save changes</button></div></form></section>`, 'profile');
}

function requireAuth(route) {
  if (!state.user) {
    go('login');
    return false;
  }
  if (route === 'admin' && state.user.role !== 'admin') {
    go('dashboard');
    return false;
  }
  return true;
}

function render() {
  if (!initialized) {
    app.innerHTML = `<main id="main" class="page"><div class="container"><div class="notice"><span>${icon('shield')}</span><div><strong>Opening CampusVoice</strong><div class="small">Verifying your secure session…</div></div></div></div></main>`;
    return;
  }
  const raw = location.hash.replace(/^#\/?/, '') || 'home';
  const [route, parameter] = raw.split('/');
  if (['dashboard','admin','complaints','new','testing','profile','complaint'].includes(route) && !requireAuth(route)) return;
  if (state.user && route === 'home') return go(state.user.role === 'admin' ? 'admin' : 'dashboard');
  const views = {
    home: landing,
    login: () => authPage('login'),
    register: () => authPage('register'),
    dashboard,
    admin: adminDashboard,
    complaints: complaintsPage,
    new: newComplaint,
    complaint: () => complaintDetail(decodeURIComponent(parameter || '')),
    security: securityPage,
    testing: testingPage,
    profile: profilePage
  };
  app.innerHTML = (views[route] || landing)();
  window.scrollTo(0, 0);
  bindEvents();
}

async function completeAuthentication(data, message) {
  state.user = data.user;
  csrfToken = data.csrfToken;
  await loadComplaints();
  toast('Signed in', message || `Welcome, ${state.user.name.split(' ')[0]}.`);
  go(state.user.role === 'admin' ? 'admin' : 'dashboard');
}

function closeCustomSelects(except = null) {
  document.querySelectorAll('[data-custom-select].open').forEach(select => {
    if (select === except) return;
    select.classList.remove('open');
    select.querySelector('[data-select-trigger]')?.setAttribute('aria-expanded', 'false');
  });
}

function openCustomSelect(select, focusSelected = false) {
  closeCustomSelects(select);
  select.classList.add('open');
  select.querySelector('[data-select-trigger]')?.setAttribute('aria-expanded', 'true');
  if (focusSelected) {
    const option = select.querySelector('[data-select-option][aria-selected="true"]') || select.querySelector('[data-select-option]');
    requestAnimationFrame(() => option?.focus());
  }
}

function chooseCustomOption(option) {
  const select = option.closest('[data-custom-select]');
  const input = select.querySelector('input[type="hidden"]');
  const trigger = select.querySelector('[data-select-trigger]');
  const label = select.querySelector('[data-select-label]');
  const marker = trigger.querySelector('.custom-select-marker');
  input.value = option.dataset.value;
  label.textContent = option.dataset.label;
  marker.className = `custom-select-marker tone-${option.dataset.tone}`;
  trigger.classList.remove('is-placeholder');
  trigger.removeAttribute('aria-invalid');
  select.classList.remove('invalid', 'open');
  select.querySelector('.custom-select-error').hidden = true;
  select.querySelectorAll('[data-select-option]').forEach(item => item.setAttribute('aria-selected', String(item === option)));
  trigger.setAttribute('aria-expanded', 'false');
  input.dispatchEvent(new Event('change', { bubbles: true }));
  trigger.focus();
}

function validateCustomSelects(form) {
  let valid = true;
  form.querySelectorAll('[data-custom-select][data-required="true"]').forEach(select => {
    const input = select.querySelector('input[type="hidden"]');
    const trigger = select.querySelector('[data-select-trigger]');
    const error = select.querySelector('.custom-select-error');
    const missing = !input.value;
    select.classList.toggle('invalid', missing);
    trigger.toggleAttribute('aria-invalid', missing);
    error.hidden = !missing;
    if (missing && valid) {
      valid = false;
      trigger.focus();
      openCustomSelect(select);
    }
  });
  return valid;
}

function bindEvents() {
  document.querySelectorAll('[data-route]').forEach(button => button.addEventListener('click', () => go(button.dataset.route)));
  document.querySelectorAll('[data-scroll]').forEach(button => button.addEventListener('click', () => document.querySelector(`#${button.dataset.scroll}`)?.scrollIntoView()));
  document.querySelector('[data-action="toggle-nav"]')?.addEventListener('click', () => { state.navOpen = !state.navOpen; render(); });
  document.querySelectorAll('[data-action="logout"]').forEach(button => button.addEventListener('click', async () => {
    try { await api('/auth/logout', { method: 'POST' }); } catch {}
    state.user = null;
    state.complaints = [];
    csrfToken = null;
    go('home');
    toast('Signed out', 'Your secure session has ended.');
  }));
  document.querySelector('[data-action="show-password"]')?.addEventListener('click', event => {
    const input = document.querySelector('#password');
    input.type = input.type === 'password' ? 'text' : 'password';
    event.currentTarget.textContent = input.type === 'password' ? 'Show' : 'Hide';
  });
  document.querySelectorAll('[data-complaint]').forEach(row => {
    const open = () => go(`complaint/${encodeURIComponent(row.dataset.complaint)}`);
    row.addEventListener('click', open);
    row.addEventListener('keydown', event => { if (event.key === 'Enter') open(); });
  });

  document.querySelector('#login-form')?.addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    const data = Object.fromEntries(new FormData(form));
    setBusy(form, true, 'Signing in…');
    try {
      await completeAuthentication(await api('/auth/login', { method: 'POST', body: JSON.stringify(data) }));
    } catch (error) {
      toast('Sign in failed', error.message);
      setBusy(form, false);
    }
  });

  document.querySelector('#register-form')?.addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    if (!validateCustomSelects(form)) return;
    const data = Object.fromEntries(new FormData(form));
    setBusy(form, true, 'Creating account…');
    try {
      const result = await api('/auth/register', { method: 'POST', body: JSON.stringify(data) });
      await completeAuthentication(result, 'Your secure account is ready.');
    } catch (error) {
      toast('Account not created', error.message);
      setBusy(form, false);
    }
  });

  document.querySelector('#complaint-form')?.addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    if (!validateCustomSelects(form)) return;
    const data = Object.fromEntries(new FormData(form));
    if (String(data.description).trim().length < 30) {
      toast('More detail needed', 'Please provide at least 30 characters in the description.');
      return;
    }
    setBusy(form, true, 'Submitting…');
    try {
      const result = await api('/complaints', {
        method: 'POST',
        body: JSON.stringify({
          title: data.title,
          category: data.category,
          date: data.date,
          location: data.location,
          confidential: data.confidential === 'on',
          description: data.description,
          outcome: data.outcome
        })
      });
      state.complaints.unshift(result.complaint);
      toast('Complaint submitted', `Reference ${result.complaint.id} has been created.`);
      go(`complaint/${encodeURIComponent(result.complaint.id)}`);
    } catch (error) {
      toast('Submission failed', error.message);
      setBusy(form, false);
    }
  });

  document.querySelector('#complaint-search')?.addEventListener('input', event => { state.query = event.target.value; render(); requestAnimationFrame(() => { const input = document.querySelector('#complaint-search'); input?.focus(); input?.setSelectionRange(state.query.length, state.query.length); }); });
  document.querySelector('#status-filter-input')?.addEventListener('change', event => { state.filter = event.target.value; render(); });
  document.querySelector('#complaint-status-input')?.addEventListener('change', async event => {
    const reference = decodeURIComponent(location.hash.replace(/^#\/?complaint\//, ''));
    try {
      const result = await api(`/complaints/${encodeURIComponent(reference)}`, { method: 'PATCH', body: JSON.stringify({ status: event.target.value }) });
      const index = state.complaints.findIndex(item => item.id === reference);
      if (index >= 0) state.complaints[index] = result.complaint;
      toast('Status updated', `${reference} is now ${result.complaint.status}.`);
      render();
    } catch (error) {
      toast('Update failed', error.message);
      render();
    }
  });
  document.querySelector('#profile-form')?.addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const name = new FormData(form).get('name').trim();
    if (!name) return;
    setBusy(form, true, 'Saving…');
    try {
      const result = await api('/profile', { method: 'PUT', body: JSON.stringify({ name }) });
      state.user = result.user;
      toast('Profile updated', 'Your changes were saved securely.');
      render();
    } catch (error) {
      toast('Update failed', error.message);
      setBusy(form, false);
    }
  });
}

document.addEventListener('click', event => {
  const option = event.target.closest('[data-select-option]');
  if (option) {
    chooseCustomOption(option);
    return;
  }
  const trigger = event.target.closest('[data-select-trigger]');
  if (trigger) {
    const select = trigger.closest('[data-custom-select]');
    if (select.classList.contains('open')) closeCustomSelects();
    else openCustomSelect(select);
    return;
  }
  closeCustomSelects();
});

document.addEventListener('keydown', event => {
  const trigger = event.target.closest('[data-select-trigger]');
  if (trigger && ['ArrowDown', 'ArrowUp', 'Enter', ' '].includes(event.key)) {
    event.preventDefault();
    openCustomSelect(trigger.closest('[data-custom-select]'), true);
    return;
  }
  const option = event.target.closest('[data-select-option]');
  if (!option) {
    if (event.key === 'Escape') closeCustomSelects();
    return;
  }
  const select = option.closest('[data-custom-select]');
  const options = [...select.querySelectorAll('[data-select-option]')];
  const current = options.indexOf(option);
  if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
    event.preventDefault();
    const offset = event.key === 'ArrowDown' ? 1 : -1;
    options[(current + offset + options.length) % options.length].focus();
  } else if (event.key === 'Home' || event.key === 'End') {
    event.preventDefault();
    options[event.key === 'Home' ? 0 : options.length - 1].focus();
  } else if (event.key === 'Escape') {
    event.preventDefault();
    closeCustomSelects();
    select.querySelector('[data-select-trigger]')?.focus();
  }
});

function categoryDepartment(category) {
  const map = {
    Academic: 'Academic Affairs',
    'Fees & Payments': 'Bursary',
    Examinations: 'Examinations & Records',
    Facilities: 'Works & Maintenance',
    'Harassment or Misconduct': 'Student Affairs',
    'Student Services': 'Student Affairs',
    Security: 'Campus Security',
    Other: 'Student Affairs'
  };
  return map[category] || 'Student Affairs';
}

window.addEventListener('hashchange', render);

async function bootstrap() {
  render();
  try {
    const session = await api('/auth/session');
    state.user = session.user;
    csrfToken = session.csrfToken;
    await loadComplaints();
  } catch (error) {
    console.error('CampusVoice startup failed', error);
  } finally {
    initialized = true;
    render();
  }
}

bootstrap();
